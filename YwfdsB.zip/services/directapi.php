<?php
	ini_set('max_execution_time', -1);
	$username="root";
	$password="";
	$database="sitara";

	// Opens a connection to a MySQL server
	$connection=mysqli_connect('localhost', $username, $password,$database);
	if (!$connection)
	{
	  die('Not connected : ' . mysqli_error());
	}

	// Set the active MySQL database
	$db_selected = mysqli_select_db( $connection,$database);
	if (!$db_selected)
	{
	  die ('Can\'t use db : ' . mysqli_error());
	}

function clean($string) {
   $string = str_replace('', '-', $string); // Replaces all spaces with hyphens.

   return preg_replace('/[^A-Za-z0-9]/', '', $string); // Removes special chars.
}


//twsitara start

$fileman_twsitara = "http://203.175.74.153/AgilityWebApi/api/Values/GetVehiclesByLogin_Test?key=e4dafbca-9049-439b-aabd-68e0b4aa7de4";
$data_twsitara = file_get_contents($fileman_twsitara);
$array_twsitara = json_decode($data_twsitara,true);

foreach($array_twsitara["Response"] as $row_twsitara){
	
	$RecordDateTime_twsitara = $row_twsitara["RecordDateTime"];
	$time_server_twsitara = str_replace("T"," ",$RecordDateTime_twsitara);
	
	 $id_twsitara = $row_twsitara["UnitMasterID"];
	
	 $imei_twsitara = "tw".$row_twsitara["UnitID"];
	
	 $vehicle_twsitara = $row_twsitara["Alias"];
	 
	 $reason_twsitara = $row_twsitara["Reason"];
	
	 $LAT_twsitara = $row_twsitara["LAT"];
	
	 $LON_twsitara = $row_twsitara["LON"];
	
	 $LandMark_twsitara = $row_twsitara["LandMark"];
	
	 $Speed_twsitara = $row_twsitara["Speed"];
	if ($Speed_twsitara > '0'){
		 $ign_sitara = 'On';
	}
	else{
		 $ign_sitara = 'Off';
	}
	
	 
	
	
	
	
	 $sql_twsitara = "INSERT INTO bulkdata (id,imei,st_server,lat,lng,angle,speed,name,sim_number,odometer,list,protocol,last_idle,last_move,last_stop,status)
 VALUES ('tw_sitara','$imei_twsitara','$time_server_twsitara','$LAT_twsitara','$LON_twsitara','360','$Speed_twsitara','$vehicle_twsitara','$id_twsitara','3321','$ign_sitara','tw_sitara','$time_server_twsitara','$time_server_twsitara','$LandMark_twsitara','0');";
mysqli_query( $connection,$sql_twsitara);


}

//twsitara end

$fileman1 = 'http://202.163.104.121/APIService/GetVehicleStatus.php?username=gas.oil&userpass=oil&choice=All';
$data1 = file_get_contents($fileman1);
$str = substr($data1, 11, -5);
$array1 = json_decode($str,true);


foreach($array1 as $rowtpl){
	
	 $imei 					= clean($rowtpl["RegistrationNo"]);
	 $name 					= $rowtpl["RegistrationNo"];
	 $lat 					= $rowtpl["Latitude"];
	 $lng					= $rowtpl["Longitude"];
	 $angle 				= $rowtpl["Direction"];
	 $speed 				= $rowtpl["Speed"];
	 $datetime 				= $rowtpl["GPSDateTime"];
	 $licensepn 			= '112113114115';
	 $odometer 				= '000';
	 $ignetion 				= $rowtpl["IgnitionStatus"];
	 $protocol 				= "al_shyma";
	 $last_idle 			= '000';
	 $last_move 			= '000';
	 $last_stop 			= $rowtpl["Location"];
	
	$sqlshy = "INSERT INTO bulkdata (id,imei,st_server,lat,lng,angle,speed,name,sim_number,odometer,list,protocol,last_idle,last_move,last_stop,status)
VALUES ('al_shyma','$imei','$datetime','$lat','$lng','$angle','$speed','$name','$licensepn','$odometer','$ignetion','$protocol','$last_idle','$last_move','$last_stop','0');";


mysqli_query( $connection,$sqlshy);
}
?>





     <div class="progress">
  <div class="progress-bar" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $i;?>%">
    <span class="sr-only"> <?php  ?></span>
  </div>
</div>
</div>
<?php
	
			
			if ($sql_twsitara == true) {
				echo "<br> New record created successfully yeahoo Tracking World ";
				
			} else {
			   echo "Error: " . $sql_twsitara . "<br>" . mysqli_error($connection);
			  
			}
			if ($sqlshy == true) {
				echo "<br> New record created successfully yeahoo Al Shyma ";
				
			} else {
			   echo "Error: " . $sqlshy . "<br>" . mysqli_error($connection);
			  
			}


$sql1= mysqli_query  ( $connection,"SELECT COUNT(*) as num FROM bulkdata" );
 
  $result = mysqli_fetch_assoc ( $sql1 );
  echo '<br>'.$result['num'];
  $t_row = $result['num'];
mysqli_close($connection);
?>
 <!DOCTYPE html>
 <html>
 <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 	<meta http-equiv="refresh" content="20">
 	<title>Sitara Data</title>
	<style>
	.progress {
    height: 3px !important;
    margin-bottom: 1px !important;
}
	</style>
 </head>
 <body style="background: #fff;">
 <div class="col-md-8">

<div class="col-md-12">
 	<br>
 	<?php echo "Successfully done"."<br>"; echo date("d-m-Y H:i:s", time()); ?>
	</div>
 </body>
 </html>